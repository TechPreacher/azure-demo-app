"""Pydantic models for Azure services."""

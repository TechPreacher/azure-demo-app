"""Azure Services Backend - FastAPI application."""
